using ProArch.CodingTest.External;
using ProArch.CodingTest.Summary;
using ProArch.CodingTest.Suppliers;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ProArch.CodingTest.Invoices
{
  public class InvoiceRepository
  {
    private readonly SupplierService _supplierService;
    private readonly FailoverInvoiceService _failoverInvoiceService;
    public InvoiceRepository()
    {
      _supplierService = new SupplierService();
      _failoverInvoiceService = new FailoverInvoiceService();
    }

    private IQueryable<Invoice> Get()
    {
      return GetInvoicesFromSource().AsQueryable();
    }


    /// <summary>
    /// Get Spent details of internal suppliers:
    /// this method gets invoice details of the internal supplier and
    ///calculate spendt details for the year.
    /// </summary>
    /// <param name="id">supplier identifier</param>
    /// <returns>list for spend details</returns>
    public List<SpendDetail> GetInternalSupplierSpendDetails(int id)
    {
      return Get().Where(x => x.SupplierId == id).GroupBy(x => x.InvoiceDate.Year)
          .Select(g => new
          SpendDetail
          {
            TotalSpend = g.Sum(s => s.Amount),
            Year = g.FirstOrDefault().InvoiceDate.Year
          }).ToList();
    }


    /// <summary>
    /// Get Spent details of External suppliers:
    /// this method gets invoice details of the external supplier and
    ///calculate spendt details for the year.
    /// </summary>
    /// <param name="id">supplier identifier</param>
    /// <returns>list for spend details</returns>
    public List<SpendDetail> GetExternalSupplierSpendDetails(string id)
    {

      return ExternalInvoiceService.GetInvoices(id).GroupBy(x => x.Year)
            .Select(g => new SpendDetail { TotalSpend = g.FirstOrDefault().TotalAmount, Year = g.FirstOrDefault().Year }).ToList();
    }


    /// <summary>
    /// Get Spent details of External suppliers:
    /// this method gets invoice details of the external supplier
    /// if external supplier service is failed to render the data
    /// and calculate spendt details for the year.
    /// </summary>
    /// <param name="id">supplier identifier</param>
    /// <returns>list for spend details</returns>
    public List<SpendDetail> GetFailoverSpendDetails(int id)
    {
      var failoverInvoices = _failoverInvoiceService.GetInvoices(id);
      if (failoverInvoices != null)
      {
        return _failoverInvoiceService.GetInvoices(id).Invoices.GroupBy(x => x.Year)
           .Select(g => new SpendDetail { TotalSpend = g.FirstOrDefault().TotalAmount, Year = g.FirstOrDefault().Year }).ToList();
      }
      else
      {
        return new List<SpendDetail>();
      }

    }


    /// <summary>
    /// this method gets the spend summary of the supplier
    /// methode gets the supplier details from supplier service
    /// and creates the spend summary using supplier name and the spend details of the supplier
    /// </summary>
    /// <param name="id">supplier identifier</param>
    /// <returns>spend summary of the supplier</returns>
    public SpendSummary GetSpendSummary(int id)
    {
      int numberOfInvokes = 0;
      SpendSummary spendSummary = new SpendSummary();
      var supplier = _supplierService.GetById(id);
      if (supplier.IsExternal)
      {
        if (GetExternalSupplierSpendDetails(id.ToString()).Any() )
        {
          if (numberOfInvokes < 3)
          {
            numberOfInvokes += 1;

            var externalSupplierSpendSummary = GetExternalSupplierSpendDetails(id.ToString());
            if (externalSupplierSpendSummary.Any())
            {
              spendSummary.Name = supplier.Name;
              spendSummary.Years = externalSupplierSpendSummary;
            }
            else
            {
              externalSupplierSpendSummary = GetExternalSupplierSpendDetails(id.ToString());
            }
            
          }
          else
          {
            var failoverSpendSummary = GetFailoverSpendDetails(id);
            spendSummary.Name = supplier.Name;
            spendSummary.Years = failoverSpendSummary;
          }

        }
        

      }
      else
      {
        var internalSupplierSpendSummary = GetInternalSupplierSpendDetails(id);
        spendSummary.Name = supplier.Name;
        spendSummary.Years = internalSupplierSpendSummary;
      }
      return spendSummary;
    }

    /// <summary>
    /// this method is to get invoices from data sources.
    /// this is returning a dummy data for both internal and external suppliers for now
    /// </summary>
    /// <returns>list of invoices</returns>
    List<Invoice> GetInvoicesFromSource()
    {
      List<Invoice> invoices = new List<Invoice>();
      invoices.Add(new Invoice() { SupplierId = 1, Amount = 100, InvoiceDate = DateTime.Now.AddDays(-10) });
      invoices.Add(new Invoice() { SupplierId = 2, Amount = 110, InvoiceDate = DateTime.Now.AddDays(-15) });
      invoices.Add(new Invoice() { SupplierId = 3, Amount = 120, InvoiceDate = DateTime.Now.AddDays(-20) });
      invoices.Add(new Invoice() { SupplierId = 4, Amount = 130, InvoiceDate = DateTime.Now.AddDays(-25) });
      return invoices;
    }

  }
}

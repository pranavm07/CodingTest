using System;
using System.Linq;

namespace ProArch.CodingTest.Invoices
{
  public class FailoverInvoiceService
  {
    private readonly FailoverInvoiceCollection _failoverInvoiceCollection;
    public FailoverInvoiceService()
    {
      _failoverInvoiceCollection = new FailoverInvoiceCollection();
    }
    public FailoverInvoiceCollection GetInvoices(int supplierId)
    {
      FailoverInvoiceCollection failoverInvoiceCollection = new FailoverInvoiceCollection();
      if (DateTime.Now.Subtract(_failoverInvoiceCollection.Timestamp).Days / (365.25 / 12) > 1)
      {
        return null;
      }
      else
      {
       return new FailoverInvoiceCollection();
      }
    }
  }
}

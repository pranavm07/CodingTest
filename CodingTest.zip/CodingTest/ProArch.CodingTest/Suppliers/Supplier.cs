﻿namespace ProArch.CodingTest.Suppliers
{
    public class Supplier
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public bool IsExternal { get; set; }
    }
}
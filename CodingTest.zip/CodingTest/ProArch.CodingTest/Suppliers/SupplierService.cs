using System.Collections.Generic;
using System.Linq;

namespace ProArch.CodingTest.Suppliers
{
  public class SupplierService
  {
    
    public Supplier GetById(int id)
    {
      return GetSupplierData(id);
    }
    Supplier GetSupplierData(int id)
    {
      List<Supplier> suppliers = new List<Supplier>();
      // Get supplier list from data source
      suppliers.Add(new Supplier() { Id=1, IsExternal=false, Name="Supplier1"});
      suppliers.Add(new Supplier() { Id = 2, IsExternal = false, Name = "Supplier2" });
      suppliers.Add(new Supplier() { Id = 3, IsExternal = false, Name = "Supplier3" });
      suppliers.Add(new Supplier() { Id = 4, IsExternal = true, Name = "Supplier4" });
      return suppliers.Where(x => x.Id == id).FirstOrDefault();
    }
  }
}

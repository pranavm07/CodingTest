﻿namespace ProArch.CodingTest.Summary
{
    public class SpendDetail
    {
        public int Year { get; set; }
        public decimal TotalSpend { get; set; }
    }
}
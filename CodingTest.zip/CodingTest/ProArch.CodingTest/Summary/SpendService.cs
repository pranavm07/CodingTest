using ProArch.CodingTest.Invoices;

namespace ProArch.CodingTest.Summary
{
  public class SpendService
  {
    private readonly InvoiceRepository _invoiceRepository;
    
    public SpendService()
    {
      _invoiceRepository = new InvoiceRepository();
    }
    public SpendSummary GetTotalSpend(int supplierId)
    {
      return _invoiceRepository.GetSpendSummary(supplierId);
    }
  }
}

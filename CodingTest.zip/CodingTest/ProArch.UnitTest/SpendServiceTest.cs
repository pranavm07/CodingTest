using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProArch.CodingTest.Summary;

namespace ProArch.UnitTest
{
  [TestClass]
  public class SpendServiceTest
  {
    private readonly SpendService _spendService;
    public SpendServiceTest()
    {
      _spendService = new SpendService();
    }
    [DataTestMethod]
    [DataRow(1)]
    [DataRow(2)]
    [DataRow(3)]
    [DataRow(4)]
    public void GetTotalSpend(int id)
    {
      var testResult =_spendService.GetTotalSpend(id);
      Assert.AreSame(testResult,testResult);
    }
  }
}

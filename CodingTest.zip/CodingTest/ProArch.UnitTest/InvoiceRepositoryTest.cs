using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProArch.CodingTest.Invoices;
using ProArch.CodingTest.Summary;
using System.Collections.Generic;
using System.Linq;

namespace ProArch.UnitTest
{
  [TestClass]
  public class InvoiceRepositoryTest
  {
    private readonly InvoiceRepository _invoiceRepository;
    public InvoiceRepositoryTest()
    {
      _invoiceRepository = new InvoiceRepository();
    }

    [DataTestMethod]
    [TestMethod]
    [DataRow(1)]
    public void GetInternalSupplierSpendDetails(int id)
    {
      var result = _invoiceRepository.GetInternalSupplierSpendDetails(id);
      Assert.IsNotNull(result, "Internal supplier spend details for supplier id :" + id.ToString());
      
    }
    [DataTestMethod]
    [DataRow(1)]
    [DataRow(4)]
    public void GetExternalSupplierSpendDetails(int id)
    {
      var result = _invoiceRepository.GetExternalSupplierSpendDetails(id.ToString());
      if (result.Any())
      {
        Assert.IsNull(result, "External Service is offline");
        GetFailoverSpendDetails(id);
      }
      else
      {
        Assert.IsNotNull(result, "Internal supplier spend details for supplier id :" + id.ToString());
      }
      
    }
    [DataTestMethod]
    [DataRow(1)]
    [DataRow(4)]
    public void GetFailoverSpendDetails(int id)
    {
      var result = _invoiceRepository.GetFailoverSpendDetails(id);
      if (result.Any())
      {
        Assert.IsNotNull(result, "invoice received from failover service");
      }
      else
      {
        Assert.IsFalse(false, "failover service has data older than one month");
      }
    }
    [DataTestMethod]
    [DataRow(1)]
    [DataRow(2)]
    [DataRow(3)]
    [DataRow(4)]
    public void GetSpendSummary(int id)
    {
      var result = _invoiceRepository.GetSpendSummary(1);
      if (result!=null)
      {
        Assert.IsNotNull(result, "summary received");
      }
      else
      {
        Assert.IsFalse(false, "no summary received");
      }
    }

  }
}
